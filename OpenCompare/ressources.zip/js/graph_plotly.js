
function loadJSON(callback, filePath) {
  var xobj = new XMLHttpRequest();
  xobj.overrideMimeType("application/json");
  xobj.open('GET', filePath, false);
  //xobj.open('GET', 'json/matrice.json', false); // Replace 'my_data' with the path to your file
  xobj.onreadystatechange = function () {
        if (xobj.readyState == 4 && xobj.status == "200") {
          // Required use of an anonymous callback as .open will NOT return a value but simply returns undefined in asynchronous mode
          callback(xobj.responseText);
        }
  };
  xobj.send(null);
}

loadJSON(function(response) {
var obj = JSON.parse(response);
//var layout = {title: obj.titre,showlegend: false, height: 720, width: 1240};
var layout = {
      title: obj.titre,
      xaxis: {
        title: obj.labelx,
        showline: true,
        mirror: 'allticks',
        ticks: 'inside'
      },
      yaxis: {
        title: obj.labely,
        showline: true,
        mirror: 'allticks',
        ticks: 'inside'
      },
    showlegend: false,
    height: 720,
    width: 1240
  };
  loadJSON(function(response) {
   // Parse JSON string into object
  console.log(JSON.parse(response));

  //var data1 = [{"text":["D5500","D5100","D40","D4","D600","D5200","D1","D100","D2X","D7100","D5300","D1X","D60","D3","D1H","D70","D50","D810","D3000","D7200","D610","D300S","D70s","Df","D5000","D40X","D4S","D90","D80","D750","D2H","D3S","D700","D3300","D3100","D7000","D2Xs","D200","D3X","D2Hs","D800","D3200","D300"],"x":["25600","6400","1600","12800","6400","6400","1600","1600","800","6400","12800","800","1600","6400","1600","1600","1600","12800","1600","25600","6400","3200","1600","12800","3200","1600","12800","3200","1600","12800","1600","12800","6400","12800","3200","6400","800","1600","1600","1600","6400","6400","3200"],"y":["25600","25600","3200","204800","25600","25600","1600","1600","800","25600","25600","800","3200","25600","1600","1600","1600","51200","3200","102400","25600","6400","1600","204800","6400","1600","409600","6400","3200","51200","1600","102400","25600","25600","12800","25600","3200","1600","6400","6400","25600","12800","6400"],"mode":"markers","marker":{"size":["100","100","200","100","100","100","200","200","100","100","100","125","100","200","200","200","200","64","100","100","100","200","200","100","200","100","100","200","100","100","200","200","200","100","100","100","100","100","100","200","100","100","200"],"color":["201","420","420","910","201","201","100","100","100","201","201","100","420","100","100","100","420","910","420","201","201","100","100","201","420","420","910","420","420","910","100","105","105","420","420","201","105","105","105","105","910","420","105"]}}];
  //console.log(data1);
  //console.log(layout);
  Plotly.newPlot('graph',JSON.parse(response), layout);
  },'json/plotly.json');

},'json/param.json');

// create the chart
